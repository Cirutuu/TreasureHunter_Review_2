package model;

public enum CellType {
    EMPTY, WALL, CASH
}
