package analytics;

import java.util.*;

public class GameStats {

    private static List<Integer> leaderboard = new ArrayList<>();

    public static void addScore(int score) {
        leaderboard.add(score);
        mergeSort(leaderboard, 0, leaderboard.size() - 1);
    }

    public static List<Integer> getTopScores() {
        return leaderboard.subList(0, Math.min(5, leaderboard.size()));
    }

    // ================= MERGE SORT =================
    private static void mergeSort(List<Integer> arr, int left, int right) {
        if (left >= right) return;

        int mid = (left + right) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }

    private static void merge(List<Integer> arr, int left, int mid, int right) {
        List<Integer> temp = new ArrayList<>();
        int i = left, j = mid + 1;

        while (i <= mid && j <= right) {
            if (arr.get(i) > arr.get(j))
                temp.add(arr.get(i++));
            else
                temp.add(arr.get(j++));
        }

        while (i <= mid) temp.add(arr.get(i++));
        while (j <= right) temp.add(arr.get(j++));

        for (int k = 0; k < temp.size(); k++) {
            arr.set(left + k, temp.get(k));
        }
    }
}