package ui;

import analytics.GameStats;
import engine.AIEngine;
import engine.AlgorithmType;
import java.awt.*;
import javax.swing.*;
import model.Player;
import util.Difficulty;

public class EndCard extends JFrame {
    public EndCard(Player h, Player c, int size, engine.AlgorithmType algo, boolean isColorBlindMode) {
        setTitle("Game Over");
        setSize(300, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        String winner = h.score > c.score ? "Human Wins!" : c.score > h.score ? "CPU Wins!" : "Draw";
        String message = h.score > c.score * 2 ? "Crushing Victory!" : c.score > h.score * 2 ? "CPU Dominates!" : "Close Match!";

        JTextArea t = new JTextArea(
                String.format("%s\n%s\n\nHuman ₹%d\nCPU ₹%d\nHuman Moves: %d\nCPU Moves: %d\nAlgorithm: %s",
                        winner, message, h.score, c.score, h.moves, c.moves, algo)
        );
        t.setEditable(false);
        t.setFont(new Font("Arial", Font.PLAIN, 14));
        t.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel buttonPanel = new JPanel();
        JButton restart = new JButton("Restart");
        JButton mainMenu = new JButton("Main Menu");
        JButton quit = new JButton("Quit");

        restart.addActionListener(e -> {
            dispose();
            new GameUI(size, algo,Difficulty.MEDIUM, isColorBlindMode);
        });
        mainMenu.addActionListener(e -> {
            dispose();
            new MainMenu();
        });
        quit.addActionListener(e -> System.exit(0));

        buttonPanel.add(restart);
        buttonPanel.add(mainMenu);
        buttonPanel.add(quit);

        add(t, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        setVisible(true);
    }
}