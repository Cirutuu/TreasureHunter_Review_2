package engine;

public enum AlgorithmType {
    BFS,
    DFS,
    GREEDY,
    DNC   
}